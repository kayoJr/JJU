<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <title>College of Veterinary Medicine</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <meta name="description" content="" />
  <meta name="author" content="" />

  <!-- css -->
  <link href="https://fonts.googleapis.com/css?family=Noto+Serif:400,400italic,700|Open+Sans:300,400,600,700" rel="stylesheet">
  <link href="css/bootstrap.css" rel="stylesheet" />
  <link href="css/bootstrap-responsive.css" rel="stylesheet" />
  <link href="css/fancybox/jquery.fancybox.css" rel="stylesheet">
  <link href="css/jcarousel.css" rel="stylesheet" />
  <link href="css/flexslider.css" rel="stylesheet" />
  <link href="css/style.css" rel="stylesheet" />
  <!-- Theme skin -->
  <link href="skins/default.css" rel="stylesheet" />
  <!-- Fav and touch icons -->
  <link rel="apple-touch-icon-precomposed" sizes="144x144" href="ico/apple-touch-icon-144-precomposed.png" />
  <link rel="apple-touch-icon-precomposed" sizes="114x114" href="ico/apple-touch-icon-114-precomposed.png" />
  <link rel="apple-touch-icon-precomposed" sizes="72x72" href="ico/apple-touch-icon-72-precomposed.png" />
  <link rel="apple-touch-icon-precomposed" href="ico/apple-touch-icon-57-precomposed.png" />
  <link rel="shortcut icon" href="ico/favicon.png" />

</head>

<body>
  <div id="wrapper">
    <!-- start header -->
    
            <?php include './header.php'; ?>
        <!-- end header -->
       
        <div class="row">
          <div class="span4">
            <div class="logo">
              <a href="index.php"><img src="img/lo.png" alt="" class="logo" /></a>
            </div>
          </div>
            
          <div class="span8">
            <div class="navbar navbar-static-top pull-left">
              <div class="navigation">
                <nav>
                  <ul class="nav topnav" style="padding-top:20px;">
                     
                    <li>
                      <a href="index.php">Home</a>
                    </li>
					<li class="dropdown">
                      <a href="#">Administration <i class="icon-angle-down"></i></a>
                      <ul class="dropdown-menu">
                        <li class="dropdown"><a href="#">President's <i class="icon-angle-right"></i></a>
                          <ul class="dropdown-menu sub-menu-level1">
                            <li><a href="">Profile</a></li>
                            <li><a href="PresidentMessage.php">Messages</a></li>
                          </ul>
                        </li>
                        
                        <li class="dropdown"><a href="#">Vice President's <i class="icon-angle-right"></i></a>
                          <ul class="dropdown-menu sub-menu-level1">
                            <li><a href="ARVPmessage.php">ARVP Message</a></li>
                            <li><a href="ADVPmessage.php">ADVP Message</a></li>
                          </ul>
                        </li>
                  </ul>
				  </li>
					<li class="dropdown">
                      <a href="#">Research<i class="icon-angle-down"></i></a>
                      <ul class="dropdown-menu">
                        <li class="dropdown"><a href="#">Directorate of Research, Publication & Technology Transfer <i class="icon-angle-right"></i></a>
                          <ul class="dropdown-menu sub-menu-level1">
                            <li><a href="aboutDRPTT.php">About</a></li>
                            <li><a href="ThematicArea.php">Thematic&nbsp;Area</a></li>
                            <li><a href="">Research&nbsp;Database</a></li>
                          </ul>
                        </li>
						<li class="dropdown"><a href="#">Offices <i class="icon-angle-right"></i></a>
                          <ul class="dropdown-menu sub-menu-level1">
                            <li><a href="Research.php">Research</a></li>
                            <li><a href="Publication.php">Publication</a></li>
                            <li><a href="">Technology&nbsp;Transfer</a></li>
                            
                          </ul>
                        </li>
						<li class="dropdown"><a href="#">Research Site <i class="icon-angle-right"></i></a>
                          <ul class="dropdown-menu sub-menu-level1">
                            <li><a href="poultery.php">Poultry</a></li>
							<li><a href="farm.php">Farm</a></li>
							<li><a href="Nursery.php">Nursery</a></li>
                          </ul>
                        </li>
                      </ul>
                    </li>
					
					<li class="dropdown active">
                      <a href="#">Academic<i class="icon-angle-down"></i></a>
                      <ul class="dropdown-menu">
                        <li class="dropdown"><a href="#">Colleges <i class="icon-angle-right"></i></a>
                          <ul class="dropdown-menu sub-menu-level1">
                            <li><a href="eng&tech.php">Engineering&nbsp;&amp;&nbsp;Technology</a></li>
                            <li><a href="coMHS.php">Medicine&nbsp;&amp;&nbsp;Health&nbsp;science</a></li>
                            <li><a href="cda.php">Dryland&nbsp;Agriculture</a></li>
							<li><a href="coEBS.php">Education&nbsp;&amp;&nbsp;Behavioural&nbsp;studies</a></li>
							<li><a href="cvm.php">Veterinary&#8303;&nbsp;&nbsp;Medicine</a></li>
							<li><a href="coBE.php">Business&nbsp;&amp;&nbsp;Economics</a></li>
							<li><a href="CSSH.php">Social&nbsp;Sciences&nbsp;&amp;&nbsp;Humanities</a></li>
							<li><a href="CNCS.php">Natural&nbsp;&amp;&nbsp;Computational&nbsp;Science</a></li>
                          </ul>
                        </li>
						<li class="dropdown"><a href="#">Schools <i class="icon-angle-right"></i></a>
                          <ul class="dropdown-menu sub-menu-level1">
                            <li><a href="SL.php">Law</a></li>
                            <li><a href="">Psychology</a></li>
                            <li><a href="SGS.php">Graduate&nbsp;Studies</a></li>
                          </ul>
                        </li>
						<li class="dropdown"><a href="#">Institute <i class="icon-angle-right"></i></a>
                          <ul class="dropdown-menu sub-menu-level1">
                            <li><a href="ISLLS.php">Somali&nbsp;Language&nbsp;and&nbsp;Literature&nbsp;Studies</a></li>
                            
                          </ul>
                        </li>
                      </ul>
                    </li>
					<li class="dropdown">
                      <a href="#">OTHERS<i class="icon-angle-down"></i></a>
                      <ul class="dropdown-menu">
                        <li><a href="RefHospital.php">Referral Hospital</a></li>
                        <li><a href="services.php">Services</a></li>
                        <li><a href="Registrar.php">Registrar</a></li>
                      </ul>
                    </li>
                    <li>
                      <a href="about.php">About us</a>
                    </li>
					
                    <li>
                      <a href="contact.php">Contact Us</a>
                    </li>
                  </ul>
                </nav>
              </div>
              <!-- end navigation -->
            </div>
          </div>
        </div>
      </div>
    </header>
    <!-- end header -->
	
	<section id="inner-headline">
      <div class="container">
        <div class="row">
          <div class="span4">
            <div class="inner-heading">
                <h2>CVM</h2>
            </div>
          </div>
          <div class="span8">
            <ul class="breadcrumb">
              <li><a href="index.php"><i class="icon-home"></i></a><i class="icon-angle-right"></i></li>
              <li><a href="">Colleges</a><i class="icon-angle-right"></i></li>
              <li class="active">College of Veterinary Medicine</li>
            </ul>
          </div>
        </div>
      </div>
    </section>
    
<section id="content">
		<div class="container">
			<div class="row" style="margin-top:-40px;">
				<div class="span10 offset1">
				<div class="testimonial">
					<!--<div class="post-image">
						<img src="img/dummies/blog/maingate.jpg" alt="" />
					</div>-->
					<h4 class="heading"><strong>College of Veterinary Medicine</strong></h4>
					<p>
                    Though it was launched in late 2007 with the name ‘Faculty of Veterinary Medicine’, it attained the status of a college - College of Veterinary Medicine (CVM) - in the year 2011 following the institutional restructure. Besides producing regular students in CVM, the College has been training Bachelor of Science in Animal Health summer in-service training program to combat the critical shortage of trained animal health personnel in the Region.  
					</p>
					<h6>Major achievements in 2016/2017 A/C</h6>

					<p>
                    The academic staffs have organized forums (Monthly Monday Forum) and presented four scientific papers through their cooperative groups. They had undertaken a fairly good job this year in this matter. 
					</p>
						
					<p>
					Regarding research and publication, CVM has been actively engaged in research activities through different research projects funded by national institutions such as DRPTT of Jigjiga University and EIAR. Our faculty members are undertaking several problem solving researches. This year alone the college secured three mega projects which are funded by JJU, namely :

					</p>
					    <ol>
						  <li>Rabies in Ethiopian Somali Region: Epidemiology, Ethno-botanical Evaluation and intervention packages in human, domestic and wild canid (fox) population.</li>
						  <li>Major camel calf health problems and associated risk factors in selected zones of Ethiopian Somali Region</li>
						  <li>Epidemiology of zoonotic tuberculosis in selected zones of Ethiopian Somali Regional State</li>
						  
						</ol>
					<p>
					In addition, four best DVM thesis research proposals were funded by JJU as part of the student support service.  
					</p>
					<p>
					Community services are the top priority of the College and well explained by the outreach services and livestock emergency response given by the College to the local communities. To mention some of them :

					</p>
					<ul>
						  <li>Following the occurrence of outbreak of Lumpy Skin Disease (LSD) in Gursum and Jigjiga Districts, our College in collaboration with JJU-Community Service Directorate immediately mobilized its recourses (human and material) for this emergency case. Eight kebeles from Gursum district and three kebeles from Jigjiga district were covered by the intervention. Accordingly, the College managed to vaccinate over 11,000 cattle and treat over 600 animals in the affected areas. </li>
						  <li>Certain areas in Ethiopian Somali Regional State had recently experienced a severe drought due to below average rain. The drought resulted negative impact on livestock keepers through mortality and reduced productivity of livestock. The College of Veterinary Medicine had mobilized its recourses (both human and material) and had sent livestock emergency team to Dolo zone with the aim of providing primary veterinary service for drought affected livestock. By doing so, the College managed to treat 37,700 animals and vaccinate 7,264 animals in three districts.</li>
						  
					</ul>
					<p>
					The College also offers two postgraduate studies in Early Childhood Care and Education (ECCE) and Educational Leadership through both Weekend (Jigjiga and Gode centers) and Regular programs. 

					</p>
					<p>
					Moreover, A Memorandum of Understanding was signed between CVM and Jigjiga Export Slaughterhouse (JESH) P.L.C. on August 2016 to strengthen the collaboration between the parties in the areas of laboratory diagnosis, veterinary public health and practical teaching. 
 
					</p>
					<p>
					A strong relation with Ethiopian Veterinary Association has been kept. Functional working relations with various veterinary institutions of the country including National Veterinary Institute (NVI) and National Animal Health and Disease Investigation Center (NAHDIC) are also worth mentioning. 
					</p>
					<p>
					CVM plans to Launch state-of-the-art teaching and research laboratories in addition to the existing labs. It also plans to establish special enterprises (Abattoir and Vet. Pharmacy).
 
					</p>
					
					
					</div>
				</div>
			</div>
		</div>
	</section>
  

   <?php include('footer.php');?>
   
  </div>
  <a href="#" class="scrollup"><i class="icon-chevron-up icon-square icon-32 active"></i></a>
  <!-- javascript
    ================================================== -->
  <!-- Placed at the end of the document so the pages load faster -->
  <script src="js/jquery.js"></script>
  <script src="js/jquery.easing.1.3.js"></script>
  <script src="js/bootstrap.js"></script>
  <script src="js/jcarousel/jquery.jcarousel.min.js"></script>
  <script src="js/jquery.fancybox.pack.js"></script>
  <script src="js/jquery.fancybox-media.js"></script>
  <script src="js/google-code-prettify/prettify.js"></script>
  <script src="js/portfolio/jquery.quicksand.js"></script>
  <script src="js/portfolio/setting.js"></script>
  <script src="js/jquery.flexslider.js"></script>
  <script src="js/jquery.nivo.slider.js"></script>
  <script src="js/modernizr.custom.js"></script>
  <script src="js/jquery.ba-cond.min.js"></script>
  <script src="js/jquery.slitslider.js"></script>
  <script src="js/animate.js"></script>

  <!-- Template Custom JavaScript File -->
  <script src="js/custom.js"></script>

</body>
</html>
