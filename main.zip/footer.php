
    <footer>
      <div class="container">
        <div class="row">
          <div class="span6">
            <div class="widget">
              <h5 class="widgetheading">Read More</h5>
              <ul class="link-list">
			  <strong>
			  <li><a href="aboutict.php"><i class="icon-circled icon-hand-right"></i> ICT Directorate</a></li>
			  <li><a href="CSD.php"><i class="icon-circled icon-hand-right"></i> Community Service Directorate</a></li>
			  <li><a href="ITD.php"><i class="icon-circled icon-hand-right"></i> Institutional Transformation Directorate</a></li>
			<li><a href="PTSD.php"><i class="icon-circled icon-hand-right"></i> Property and transportation service Directorate</a></li>
			<li><a href="Plan.php"><i class="icon-circled icon-hand-right"></i> Plan preparation, monitoring and evaluation Directorate</a></li>
			<li><a href="WYD&HIV_AIDSPR.php"><i class="icon-circled icon-hand-right"></i> Best Practices</a></li>
				</strong>
               
              </ul>
            </div>
          </div>
        <div class="span3">
            <div class="widget">
              <h5 class="widgetheading">Useful links</h5>
              <ul class="link-list ">
			  <strong>
				<!--<li><a href=""><i class="icon-circled icon-hand-right"></i> Alumni</a></li>-->
				<!--<li><a href=""><i class="icon-circled icon-hand-right"></i> Vacancies</a></li>-->
				<li><a href="factsfigure.php"><i class="icon-circled icon-hand-right"></i> Facts & Figures</a></li>
				<!--<li><a href=""><i class="icon-circled icon-hand-right"></i> Facilities</a></li>-->
                                <li><a href="show_gallery.php"><i class="icon-circled icon-hand-right"></i> Galleries</a></li>
                <li><a href="http://10.226.5.13/" target="_blank"><i class="icon-circled icon-hand-right"></i> Quick Launch</a></li>
                <li><a href="http://webmail.jju.edu.et" target="_blank"><i class="icon-circled icon-hand-right"></i> JJU Webmail</a></li>
            <li><a href="https://fb.me/irjju" target="_blank"><i class="icon-circled icon-facebook active"></i> IRO Facebook</a></li>
            
             
             <li><a href="downloads.php" target="_blank"><i class="icon-circled icon-hand-right"></i> Student Downloads</a></li>
   
               </strong>
              </ul>
            </div>
          </div>
          <div class="span3">
            <div class="widget">
              <h5 class="widgetheading">Get in touch with us</h5>
              <address>
								<strong>E-mail: president@jju.edu.et /  info@jju.edu.et</strong><br>
								 Tel: +251 (0) 25 775 5933<br>
								 Fax: +251 (0) 25 775 5976<br>
								 P. O. Box: 1020 - Jigjiga, Ethiopia
					 		</address>
             
            </div>
          </div>
        </div>
      </div>
      <div id="sub-footer">
        <div class="container">
          <div class="row">
            <div class="span6">
              <div class="copyright">
                <p>
                  <span>&copy; 2018 All Rights Reserved to JIGJIGA University</span>
                </p>
                <div class="credits">
                  <!--
                    All the links in the footer should remain intact.
                    You can delete the links only if you purchased the pro version.
                    Licensing information: https://bootstrapmade.com/license/
                    Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/buy/?theme=Flattern
                  -->
                  Designed by ICT ADC Team
                </div>
              </div>
            </div>
            <div class="span6">
              <ul class="social-network">
                
                <li>Viewed by : <img src="https://counter11.allfreecounter.com/private/freecounterstat.php?c=9d8795c68p17d1ghffzp7gn8czygdx6l" border="0" title="" alt=""></li>
                <li>&nbsp;&nbsp;&nbsp;&nbsp;</li>
                
                <li><a href="http://www.facebook.com/jigjigauniversity" data-placement="bottom" title="Facebook"><i class="icon-facebook icon-circled icon-48 active"></i></a></li>
                
              </ul>
            </div>
          </div>
        </div>
      </div>
    </footer>