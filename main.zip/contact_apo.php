<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <title>Expats Information</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <meta name="description" content="" />
  <meta name="author" content="" />

  <!-- css -->
  <link href="https://fonts.googleapis.com/css?family=Noto+Serif:400,400italic,700|Open+Sans:300,400,600,700" rel="stylesheet">
  <link href="css/bootstrap.css" rel="stylesheet" />
  <link href="css/bootstrap-responsive.css" rel="stylesheet" />
  <link href="css/fancybox/jquery.fancybox.css" rel="stylesheet">
  <link href="css/jcarousel.css" rel="stylesheet" />
  <link href="css/flexslider.css" rel="stylesheet" />
  <link href="css/style.css" rel="stylesheet" />
  <!-- Theme skin -->
  <link href="skins/default.css" rel="stylesheet" />
  <!-- Fav and touch icons -->
  <link rel="apple-touch-icon-precomposed" sizes="144x144" href="ico/apple-touch-icon-144-precomposed.png" />
  <link rel="apple-touch-icon-precomposed" sizes="114x114" href="ico/apple-touch-icon-114-precomposed.png" />
  <link rel="apple-touch-icon-precomposed" sizes="72x72" href="ico/apple-touch-icon-72-precomposed.png" />
  <link rel="apple-touch-icon-precomposed" href="ico/apple-touch-icon-57-precomposed.png" />
  <link rel="shortcut icon" href="ico/favicon.png" />
<script src="https://www.google.com/recaptcha/api.js?render=6LfJf5kUAAAAAMPr6GUi9-vEQLo6XfcLRXoOsYno"></script>
  <script>
  grecaptcha.ready(function() {
      grecaptcha.execute('6LfJf5kUAAAAAMPr6GUi9-vEQLo6XfcLRXoOsYno', {action: 'feedback_form'}).then(function(token) {
         ...
      });
  });
  </script>
 
</head>

<body>
  <div id="wrapper">
    <!-- start header -->
    
            <?php include './header_1.php'; ?>
        <!-- end header -->
        <!--<div style="width:30px; height: 30px;"></div>-->
        <div class="row">
          <div class="span4">
            <div class="logo">
              <a href="index.php"><img src="img/lo.png" alt="" class="logo" /></a>
            </div>
          </div>
          
        </div>
      </div>
    </header>
    <!-- end header -->
    <section id="inner-headline">
      <div class="container">
        <div class="row">
          <div class="span12">
            <div class="inner-heading">
                <h2 style="font-size: 30px;">Academic Program Development & Promotion Directorate - <strong> Expats Data Hub</strong></h2>
            </div>
          </div>
          
        </div>
      </div>
    </section>
    <section id="content">
      

      <div class="container">
        <div class="row">
          <div class="span4">
            
              <?php
if(isset($_POST['btncontact']))
{
    $name = $_POST['name'];
    $visitor_email = $_POST['email'];
    $ph = $_POST['subject'];
    $message = $_POST['message'];
    
    
        $headers = "From: JJU_Website \r\n";

   // $email_from = $visitor_email;//<== update the email address
    $email_subject = $name." with ".$ph;
    $email_body = "From : $visitor_email\t\tPhone : $ph\t\tPurpose : Feedback or Contact\n\n".
                  "Dear Sir/Madam,\n$message\n\n".
    
    $to = "apo@jju.edu.et";//<== update the email address
    $to_me = "abpradeep@jju.edu.et";
//    $headers .= "Reply-To: $visitor_email \r\n";
    //Send the email!
    try
    {
    mail($to,$email_subject,$email_body,$headers);
    mail($to_me,$email_subject,$email_body,$headers);
    //done. redirect to thank-you page.
    //echo 'Your enquiry reached Us!! We will get back to you soon.';
    echo '<div class="alert alert-block alert-success">
                                    <button type="button" class="close" data-dismiss="alert">
                                        <i class="ace-icon fa fa-times"></i>
                                    </button>
                                    <i class="ace-icon fa fa-check green"></i>
                                    Your enquiry reached Us!!
                                    <strong class="green">
                                        We will get back to you soon.
                                    </strong>
                                </div>';
   // header('Refresh:2; URL=./contact.php');
    function IsInjected($str)
    {
      $injections = array('(\n+)',
                  '(\r+)',
                  '(\t+)',
                  '(%0A+)',
                  '(%0D+)',
                  '(%08+)',
                  '(%09+)'
                  );
      $inject = join('|', $injections);
      $inject = "/$inject/i";
      if(preg_match($inject,$str))
        {
        return true;
      }
      else
        {
        return false;
      }
    }

    }
    catch(Exception $e)
    {
        echo '\n Keep in touch with us!!';
    }
          //echo '<h2>Thanks for posting comment.</h2>';
        

    
   
    
    
}  
 
?> 
            <form id="feedback_form" action="" method="post" class="form-horizontal" >
              <div id="sendmessage">Your message has been sent. Thank you!</div>
              <div id="errormessage"></div >

              <div class="row">
                  <h5>Write us <strong>Here</strong></h5>
                <!--<div class="span6 form-group">-->
                <input type="text" name="name" class="form-control" style="min-width: 72%" id="name" placeholder="Your Name" data-rule="minlen:4" data-msg="Please enter at least 4 chars" required="" autofocus=""/>
                  <div class="validation"></div>
                <!--</div>-->
<!--                <div class="span6 margintop10 form-group">-->
                  <input type="email" class="form-control" style="min-width: 72%" name="email" id="email" placeholder="Your Email" data-rule="email" data-msg="Please enter a valid email" required="" />
                  <div class="validation"></div>
                <!--</div>-->
                <!--<div class="span6 margintop10 form-group">-->
                  <input type="text" class="form-control" style="min-width: 72%" name="subject" id="subject" placeholder="Tour Phone" data-rule="minlen:4" data-msg="Please enter at least 8 chars of subject" required="" />
                  <div class="validation"></div>
                <!--</div>-->
                <div class="margintop5">
                  <textarea class="form-control" style="min-width: 72%" name="message" rows="4" data-rule="minlen:10" data-msg="Please write something for us" placeholder="Message"></textarea>
                  <div class="validation"></div>
                  
                  <p class="text-center">
                  <button class="btn pull-left btn-large btn-theme margintop10" type="submit" name="btncontact">Send Message</button>
                  
                  
                  </p>
                </div>
              </div>
            </form>
          </div>
            <div class="span4"> 
            <div class="widget">
                <h5 class="widgetheading">our<strong> Address & Contacts</strong></h5>
                <address>
                    <strong>Academic Program Development & Promotion Directorate Office</strong><br>
                                New Management Building Floor No: 02 <br>
                                JigJiga University,Somali Region of Ethiopia<br>
                				<strong>Dr.Elyas Abdulahi </strong><br>APDPD Director <br>Tel: +251 913076588  <br>Email: apo@jju.edu.et (O), elyasabdulahi@gmail.com (P)<br>
                				
                                
                </address>
                <!--<address>
                    <strong>Useful Links :</strong><br>
                    <a href="" >Academic Staff Promotion</a><br>
                    <a href="" >Academic Programs</a><br>
                    <a href="" >Staff on Study Leave</a><br> -->
                            
                </address>
                
            </div>
            
            </div>
            <!--<div class="span4"> 
            <div class="widget">
                <img src="img/apo.jpg" alt="" title="" />
                
                
            </div>
            
            </div>-->
        </div>
      </div>
    </section>
    <!-- footer begin -->
  <?php include('footer.php');?>
    <!-- footer end -->
  </div>
  <a href="#" class="scrollup"><i class="icon-chevron-up icon-square icon-32 active"></i></a>
  <!-- javascript
    ================================================== -->
  <!-- Placed at the end of the document so the pages load faster -->
  <script src="js/jquery.js"></script>
  <script src="js/jquery.easing.1.3.js"></script>
  <script src="js/bootstrap.js"></script>
  <script src="js/jcarousel/jquery.jcarousel.min.js"></script>
  <script src="js/jquery.fancybox.pack.js"></script>
  <script src="js/jquery.fancybox-media.js"></script>
  <script src="js/google-code-prettify/prettify.js"></script>
  <script src="js/portfolio/jquery.quicksand.js"></script>
  <script src="js/portfolio/setting.js"></script>
  <script src="js/jquery.flexslider.js"></script>
  <script src="js/jquery.nivo.slider.js"></script>
  <script src="js/modernizr.custom.js"></script>
  <script src="js/jquery.ba-cond.min.js"></script>
  <script src="js/jquery.slitslider.js"></script>
  <script src="js/animate.js"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyD8HeI8o-c1NppZA-92oYlXakhDPYR7XMY"></script>

  <!-- Contact Form JavaScript File -->
  <script src="contactform/contactform.js"></script>

  <!-- Template Custom JavaScript File -->
  <script src="js/custom.js"></script>

</body>

</html>
